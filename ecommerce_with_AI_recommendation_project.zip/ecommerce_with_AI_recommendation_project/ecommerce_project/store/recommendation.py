from django.shortcuts import render
from .models import Product
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel

def train_recommendation_engine():
    # Load data from your Django model (replace YourProductModel with your actual model)
    products = Product.objects.all()

    # Extract descriptions from your products
    descriptions = [product.detail_description for product in products]

    # Train the TF-IDF vectorizer
    tf = TfidfVectorizer(analyzer='word', ngram_range=(1, 3), min_df=1, stop_words='english')
    tfidf_matrix = tf.fit_transform(descriptions)

    # Calculate cosine similarities
    cosine_similarities = linear_kernel(tfidf_matrix, tfidf_matrix)

    # Initialize results dictionary
    results = {}

    # Populate results dictionary with similar items for each product
    for idx, product in enumerate(products):
        similar_indices = cosine_similarities[idx].argsort()[:-100:-1]
        similar_items = [(cosine_similarities[idx][i], products[int(i)].id) for i in similar_indices]
        # First item is the item itself, so remove it
        results[product.id] = similar_items[1:]

    return results

# Call the train_recommendation_engine function and store the results
trained_results = train_recommendation_engine()

# Define a Django view function to use the trained recommendation engine
from django.shortcuts import get_object_or_404

def recommend_products(request, item_id, num=4):
    # Retrieve recommendations for the specified item_id from the trained results
    recommendations = trained_results.get(item_id, [])[:num]
    # Retrieve product objects for recommendations
    recommended_products = [(score, get_object_or_404(Product, pk=product_id)) for score, product_id in recommendations]
    return recommended_products
    #return render(request, 'productviewpage.html', {'recommended_products': recommended_products})

