from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import redirect, render

from .models import Product, Cart

@login_required(login_url='login')
def addtocart(request):
    if request.method == 'POST':
        if request.user.is_authenticated:
            prod_id = int(request.POST.get('product_id'))
            product_check = Product.objects.get(id=prod_id)

            if(product_check):
                if(Cart.objects.filter(user=request.user.id,product_id=prod_id)):
                    return JsonResponse({'status':'product already in cart'})
                else:
                    prod_qty=int(request.POST.get('product_qty'))
                    if product_check.quantity >= prod_qty:
                        obj=Cart.objects.create(user=request.user,product_id=prod_id,product_qty=prod_qty)
                        obj.save()
                        return JsonResponse({'status':'successfully moved to cart'})

                    else:
                        return JsonResponse({'status':"only"+str(product_check.quantity)+"available"})
            else:
                return JsonResponse({'status':'No such product found'})
        else:
            return JsonResponse({'status':'Login to continue'})

    return redirect("/")
@login_required(login_url='login')
def viewCart(request):
    cart = Cart.objects.filter(user=request.user).order_by('-created_at')

    context = {'cart':cart}
    return render(request,'cartView.html',context)


def destroy(request, id):
    cartitem = Cart.objects.get(id=id)
    cartitem.delete()
    messages.info(request,"cart item deleted successfully")
    return redirect("view-cart")

def updateCart(request):
    if request.method == 'POST':
        prod_id = int(request.POST.get('product_id'))
        if (Cart.objects.filter(user=request.user, product_id=prod_id)):
            prod_qty = int(request.POST.get('product_qty'))
            cart = Cart.objects.get(product_id=prod_id, user=request.user)
            cart.product_qty = prod_qty
            cart.save()
            return JsonResponse({'status':'Updated successfully'})

    return redirect('/')











