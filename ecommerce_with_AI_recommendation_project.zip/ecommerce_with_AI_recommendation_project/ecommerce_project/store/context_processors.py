from .models import Cart

from .models import Wishlist

def cart_count(request):
    if request.user.is_authenticated:
        cart_count = Cart.objects.filter(user=request.user).count()

    else:
        cart_count = 0
    return {'cart_count': cart_count}


def wishlist_count(request):
    if request.user.is_authenticated:
        wishlist_items = Wishlist.objects.filter(user=request.user)
        wishlist_count = wishlist_items.count()
    else:
        wishlist_count = 0
    return {'wishlist_count': wishlist_count}
