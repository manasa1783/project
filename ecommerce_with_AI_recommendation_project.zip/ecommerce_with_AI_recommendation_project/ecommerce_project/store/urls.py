from django.contrib.auth.views import PasswordResetConfirmView
from django.urls import path
from django.contrib.auth import views as auth_views
from . import views, cart,wishList,checkout,order


urlpatterns = [
    path('', views.home_view,name='home'),

    path('collections', views.store_view,name='collections'),
    path('collectionview/<int:id>/',views.collectionview,name='collectionview'),
    path('productview/<int:pro_id>/',views.productview,name='productview'),
    path('searchproduct', views.searchproduct, name='searchproduct'),
    path('newarrivel/', views.newItem, name='newarrivel'),

    path('allnewarrivel/', views.newItemView, name='allnewarrivel'),
    path('trending/', views.trendingItem, name='trending'),
    path('alltrending/', views.trendingItemView, name='alltrending'),

    path('product-list', views.productlistAjax, name='product-list'),

    path('register', views.registerview, name='register'),
    path('login', views.loginview, name='login'),
    path('logout',views.logoutview,name='logout'),
    path('changepassword/',views.change_password,name='changepassword'),


    ####forgot password#####

    path('reset_password/', auth_views.PasswordResetView.as_view(template_name='resetpassword/password_reset.html'), name='reset_password'),
    path('reset_password_sent/', auth_views.PasswordResetDoneView.as_view(template_name='resetpassword/password_reset_done.html'), name='password_reset_done'),
    path('reset/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view(template_name='resetpassword/password_reset_confirm.html'),name='password_reset_confirm'),
    path('reset_password_complete/', auth_views.PasswordResetCompleteView.as_view(template_name='resetpassword/password_reset_complete.html'), name='password_reset_complete'),





    path('add-to-cart',cart.addtocart,name='add-to-cart'),
    path('view-cart', cart.viewCart, name='view-cart'),
    path('update-cart',cart.updateCart,name='update-cart'),
    path('delete/<int:id>/',cart.destroy,name='delete'),




    path('wishlist',wishList.index, name='wishlist'),
    path('add-to-wishlist',wishList.addtowishlist, name='add-to-wishlist'),
    path('deletewishlist/<int:id>/', wishList.deleteWishlist, name='delete'),


    path('checkout', checkout.checkoutview, name='checkout'),
    path('payment',checkout.paymentView,name='payment'),
    path('place-order', checkout.placeorder, name='place-order'),
    path('profile', checkout.profileview, name='profile'),
    #path('profileedit', checkout.edit_profile, name='profileedit'),

    path('my-order', order.myorder, name='my-order'),
    path('orderview/<str:t_no>/', order.orderview, name='orderview'),

    path('chat-bot', views.chatbot_view, name='chat-bot'),
    path('virtual-view/<int:pk>/', views.virtualview, name='virtual-view'),

]






