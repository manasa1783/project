import random

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import redirect, render

from .models import Product, Cart,Order,OrderItem,Profile

def checkoutview(request):
    rawcart = Cart.objects.filter(user=request.user.id)
    for item in rawcart:
        if item.product_qty>item.product.quantity:
            Cart.objects.delete(id=item.id)

    cartitems = Cart.objects.filter(user=request.user)
    total_price =  0
    for item in cartitems:
        total_price = total_price + item.product.selling_price * item.product_qty
    userprofile = Profile.objects.filter(user = request.user).first()

    context = {'cartitems':cartitems,'total_price':total_price,'userprofile':userprofile}


    return render(request,'checkout.html',context)


def placeorder(request):
    if request.method == 'POST':
        currentuser = User.objects.filter(id=request.user.id).first()
        if not currentuser.first_name:
            currentuser.first_name = request.POST.get('fname')
            currentuser.last_name = request.POST.get('lname')
            currentuser.email = request.POST.get('email')
            currentuser.save()
        if not Profile.objects.filter(user=request.user):
            userprofile = Profile()
            userprofile.user = request.user
            userprofile.phone = request.POST.get('contact')
            userprofile.address = request.POST.get('address')
            userprofile.city = request.POST.get('city')
            userprofile.state = request.POST.get('state')
            userprofile.country = request.POST.get('country')
            userprofile.pincode = request.POST.get('pincode')
            userprofile.save()

        neworder = Order()
        neworder.user = request.user
        neworder.fname = request.POST.get('fname')
        neworder.lname = request.POST.get('lname')
        neworder.email = request.POST.get('email')
        neworder.phone = request.POST.get('contact')
        neworder.address = request.POST.get('address')
        neworder.city = request.POST.get('city')
        neworder.state = request.POST.get('state')
        neworder.country = request.POST.get('country')
        neworder.pincode = request.POST.get('pincode')
        neworder.payment_mode = request.POST.get('payment_mode')
        cart =Cart.objects.filter(user = request.user)
        cart_total_price = 0
        for item in cart:
            cart_total_price = cart_total_price + item.product.selling_price * item.product_qty
        neworder.total_price = cart_total_price
        trackno = 'womensclub'+str(random.randint(1111111,9999999))
        while Order.objects.filter(tracking_no = trackno) is None:
            trackno = 'womensclub'+str(random.randint(11111111,9999999))
        neworder.tracking_no = trackno
        neworder.save()
        neworderitems = Cart.objects.filter(user = request.user)
        for item in neworderitems:
            OrderItem.objects.create(order = neworder,
                                     product = item.product,
                                     price = item.product.selling_price,
                                     quantity = item.product_qty)
        orderproduct = Product.objects.filter(id=item.product_id).first()
        orderproduct.quantity = orderproduct.quantity-item.product_qty

        orderproduct.save()
        Cart.objects.filter(user = request.user).delete()
        messages.success(request,'Your order has been placed successfully')
        return redirect('/')

def paymentView(request):
    return render(request,'payment.html')


from django.shortcuts import get_object_or_404
from .models import Profile

def  profileview(request):
    profile = get_object_or_404(Profile, user=request.user)
    user = request.user


    if request.method == 'POST':
        user.first_name = request.POST.get('fname')
        user.last_name = request.POST.get('lname')
        user.email = request.POST.get('email')
        user.save()
        profile.phone = request.POST.get('contact')
        profile.address = request.POST.get('address')
        profile.city = request.POST.get('city')
        profile.state = request.POST.get('state')
        profile.country = request.POST.get('country')
        profile.pincode = request.POST.get('pincode')
        profile.save()
        messages.success(request, 'Your profile has been changed successfully')
            # Redirect or perform any other actions after saving the changes

        # Render the form with the existing profile data
    return render(request, 'profile.html', {'profile': profile})








        











