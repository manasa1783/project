import random

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import redirect, render

from .models import Order,OrderItem
@login_required(login_url='login')
def myorder(request):
    order = Order.objects.filter(user = request.user.id).order_by('-created_at')
    context = {'order':order}
    return render(request,'myorderpage.html',context)
@login_required(login_url='login')
def orderview(request,t_no):
    order = Order.objects.filter(tracking_no=t_no).filter(user=request.user).first()
    orderitem = OrderItem.objects.filter(order=order)
    context = {'order':order,'orderitem':orderitem}
    return render(request,'orderdetails.html',context)

