from django import forms
from django.contrib.auth.forms import UserCreationForm

from django import forms
from django.contrib.auth.forms import PasswordChangeForm as BasePasswordChangeForm
from django.contrib.auth.models import User
from .models import Cart, Review
from django.contrib.auth.forms import SetPasswordForm







class CustomUserForm(UserCreationForm):
    first_name= forms.CharField(widget=forms.TextInput(attrs={'class':'form-control my-2','placeholder':'enter your first name'}))
    last_name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control my-2', 'placeholder': 'enter your last name'}))
    username = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control my-2', 'placeholder': 'enter your username'}))
    email = forms.EmailField(widget =forms.TextInput(attrs={'class': 'form-control my-2', 'placeholder': 'enter your Email Id'}))
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control my-2', 'placeholder': 'enter your password'}))
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control my-2', 'placeholder': 'enter your conform password'}))
    class Meta:
        model = User
        fields = ['first_name','last_name','username','email','password1','password2']






class PasswordResetConfirmForm(SetPasswordForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['new_password1'].widget = forms.PasswordInput(attrs={'placeholder': 'New Password'})
        self.fields['new_password2'].widget = forms.PasswordInput(attrs={'placeholder': 'Confirm New Password'})




class PasswordChangeForm(BasePasswordChangeForm):
    old_password = forms.CharField(
        label='Current Password',
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
    )
    new_password1 = forms.CharField(
        label='New Password',
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
    )
    new_password2 = forms.CharField(
        label='Confirm New Password',
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
    )

    class Meta:
        model = User
        fields = ('old_password', 'new_password1', 'new_password2')

class CartForm(forms.ModelForm):
    class Meta:
        model = Cart
        fields = ['product_qty']
        widgets = {
            'product_qty': forms.NumberInput(attrs={'class': 'form-control'}),
        }



class reviewForm(forms.ModelForm):
    class Meta:

        model = Review
        fields = ['content']
        labels = {'content': ''}

        widgets = {
            'content': forms.Textarea(attrs={'rows': 2, 'class': 'form-control my-2', 'placeholder': '', 'label': ''}),        }










"""from django import forms
from .models import ProductAdd, Review, Contact


class productForm(forms.ModelForm):
    class Meta:
        model = ProductAdd
        fields = ['name','price','image','description','Category']
        labels = {
             'name':"Product Name: ",
              'price':"Price: ",
             'image':"Image: ",
             'discription':"Description",
             'category':"Category",
        }
        widgets = {
            'discription': forms.Textarea(attrs={'rows': 4}),
        }

class reviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = ['content']
        widgets = {
            'content': forms.Textarea(attrs={'rows': 3}),
        }

class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = '__all__'
        labels = {
            'name': 'Name',
            'email': 'Email Id',
            'phone': 'Contact Number',
            ' desc': 'Description',
        }
        widgets = {
            'desc': forms.Textarea(attrs={'rows': 3}),
        }"""

