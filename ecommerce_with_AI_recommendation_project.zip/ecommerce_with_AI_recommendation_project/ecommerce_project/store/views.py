from django.conf import settings
from django.contrib.auth.models import User
from django.http import JsonResponse


# Create your views here.
from django.contrib import messages,auth
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.shortcuts import render, redirect
from .models import Category, Product, Cart, Wishlist, Review
from .form import CustomUserForm, CartForm, PasswordChangeForm, reviewForm
from django.shortcuts import render, redirect, get_object_or_404
from .recommendation import recommend_products




def cart_count(request):
    cart_items = Cart.objects.filter(user=request.user)
    cart_count = cart_items.count()
    return {'cart_count': cart_count}


def home_view(request):
    newitem = Product.objects.filter(tag = 'new').order_by('-created_at')
    trendingitem = Product.objects.filter(trending=True).order_by('-created_at')



    context = {'newitem':newitem,'trendingitem':trendingitem}

    return render(request, 'index.html',context)



def store_view(request):
    category= Category.objects.all()



    dict_category = {
        'category':category,

    }

    return render(request,'collections.html',dict_category)
def collectionview(request,id):
    if Category.objects.filter(id=id,status=0):
        product = Product.objects.filter(catogory_id=id).order_by('-created_at')
        category_name=Category.objects.filter(id=id).first()
        context ={'product':product,'category_name':category_name}
        return render(request,'collectionsviews.html',context)
    else:
        messages.warning(request,'no such category found')
        return redirect('collections')





def productview(request,pro_id):
    if Product.objects.filter(id=pro_id, status=0):
         product = Product.objects.filter(id=pro_id,status=0).first()
         context={'product':product}
    else:
        messages.error(request,'No such product found')
        return redirect("collectionview")

    reviews = Review.objects.filter(product=product).order_by('-datetime')

    form = reviewForm()
    if request.method == "POST":
        form = reviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.product = product  # Set the product for the new review
            review.save()
            return redirect(f"/productview/{product.id}")
    recommended_products = recommend_products(request, pro_id)
    return render(request,"productviewpage.html",{'product':product,'form':form,'reviews':reviews,'recommended_products':recommended_products})


def productlistAjax(request):
    products = Product.objects.filter(status=0).values_list('name',flat=True)
    productlist = list(products)
    return JsonResponse(productlist, safe=False)


def searchproduct(request):
    if request.method== "POST":
        searcheditem = request.POST.get('productsearch')
        print(searcheditem)
        if searcheditem == "":
            return redirect((request.META.get('HTTP_REFERER')))
        else:
            product = Product.objects.filter(name__contains= searcheditem).first()
            if product:
                return redirect('productview/'+str(product.id))
            else:
                messages.info(request,'No product matched your search')
    return redirect((request.META.get('HTTP_REFERER')))



def registerview(request):
    form = CustomUserForm()
    if request.method=='POST':
        form = CustomUserForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,'Registerd SuccessFully!Login to continue')
            return redirect("login")

    context = {'form':form}
    return render(request, 'register.html', context)
def loginview(request):
    if request.user.is_authenticated:
        messages.warning(request,'you are already logged')
        return redirect('/')
    else:
        if request.method == 'POST':
            user_name = request.POST.get('uname')
            password = request.POST.get('pass')
            user = authenticate(username=user_name, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, 'logged in successfully')
                return redirect("/")
            else:
                messages.error(request,'invalid username or password')
                return redirect("login")
        return render(request,'login.html')
def logoutview(request):
    if request\
            .user.is_authenticated:
        logout(request)
        messages.success(request,'logged out successfully')
    return redirect('/')

def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'Your password was successfully updated!')
            return redirect('/')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = PasswordChangeForm(user=request.user)
    return render(request, 'change_password.html', {'form': form})

def forgotpasswordview(request):

    return render(request,'forgotpassword.html')



def newItem(request):
    newitem = Product.objects.filter(tag ='new').order_by('-created_at')
    newitem.reverse()
    return render(request,'newarrivel.html',{'newitem':newitem})
def newItemView(request):
    newitem = Product.objects.filter(tag ='new').order_by('-created_at')
    return render(request,'allnewarrivel.html',{'newitem':newitem})

def trendingItem(request):
    trendingitem = Product.objects.filter(trending = True).order_by('-created_at')

    return render(request,'trending.html',{'trendingitem':trendingitem})
def trendingItemView(request):
    trendingitem = Product.objects.filter(trending = True).order_by('-created_at')
    trendingitem.reverse()
    return render(request,'alltrending.html',{'trendingitem':trendingitem})


from .main import google_search

def chatbot_view(request):
    if request.method == 'POST':
        message = request.POST.get('message')
        if message.lower() in ["bye", "goodbye"]:
            response = "Goodbye! Have a great day!"
        else:
            search_results = google_search(message)
            if search_results:
                response = "Here are some search results for your query:\n"
                for idx, result in enumerate(search_results, 1):
                    response += f"{idx}. {result}\n"

            else:
                response = "Sorry, I couldn't find any relevant information. Please try another query."
        return render(request, 'search_form.html', {'response': response})
    return render(request, 'search_form.html')

def virtualview(request, pk):
    ar_objects = get_object_or_404(Product, pk=pk)
    return render(request, 'virtual_view.html', {'ar_objects': ar_objects})